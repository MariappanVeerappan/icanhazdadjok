﻿using System;
using System.Collections.Generic;
using System.Text;
using ICanHazDadJokeConsole.Model;
using System.Net.Http;
using System.Threading.Tasks;
using System.Threading;
using System.Web;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Net.Http.Headers;
using System.Reflection;

namespace ICanHazDadJokeConsole
{

    public class DadJokesService
    {
        private DadJokesSettings _settings;
        private string _responseBody;

        public DadJokesService()
        {
            // instantiate DadJokesSettings
            _settings = new DadJokesSettings();
        }

        public DadJokesSettings JokesSettings
        {
            get { return _settings; }
        }

        public void InitializeClient(HttpClient client)
        {
            foreach (var kv in _settings.clientSettings)
            {
                client.DefaultRequestHeaders.Add(kv.Key, kv.Value);
            }
        }

       

        public void FormatAndDisplayDadJokes(IList<DadJoke> jokes)
        {

            // We only want to match on the whole word
            string searchTerm = @"\b" + _settings.SearchTerm + @"\b";

            foreach (DadJoke dadJoke in jokes)
            {
                if (Regex.IsMatch(dadJoke.Joke, searchTerm))
                {
                    string formattedJoke = Regex.Replace(dadJoke.Joke, searchTerm, _settings.SearchTerm.ToUpper());
                    Console.WriteLine(formattedJoke);
                }

            }
        }

        /* Function: RepeatDadJokes(HttpClient, string, DadJokesSettings)
         * This function is called when Option 1 is selected from the UI.  It hits the API, displays the joke,
         * waits 10 seconds, and then repeats the process.
         * */
        public async Task RepeatDadJokes(CancellationTokenSource source)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    InitializeClient(client);

                    while(!source.IsCancellationRequested)
                    { 
                        _responseBody = await client.GetStringAsync(_settings.BaseURL);
                        DadJoke dadJoke = JsonConvert.DeserializeObject<DadJoke>(_responseBody);

                        if (dadJoke.Status.Equals("200") && dadJoke.Joke.Length != 0)
                        {
                            Console.WriteLine(dadJoke.Joke);
                        }

                        await Task.Delay(_settings.JokesDelay);
                    }

                }
            }

            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e);
                Console.WriteLine("Press any key to exit.");
            }
            
        }

        /* Function: SearchDadJokes(HttpClient, string, DadJokesSettings)
        * This function is called when Option 2 is selected from the UI. It
        * builds a query with parameters in order to use the /search endpoint of the API.
        * It hits the API and returns a "page" of DadJokes given the limit set in the _settings.
        * It then binds the response to the DadJokes class and returns that for us to use in later functions.
        * */
        public async Task SearchDadJokesAsync()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                  //   InitializeClient(client);
                    client.BaseAddress = new Uri(_settings.BaseURL);
                    client.DefaultRequestHeaders.UserAgent.TryParseAdd("userAgent");
                    client.DefaultRequestHeaders.Accept.ParseAdd("application / json");
                    //  UserAgent.ParseAdd("Mozilla/5.0 (compatible; AcmeInc/1.0)");

                    //   ProductHeaderValue header = new ProductHeaderValue("MyAwesomeLibrary", Assembly.GetExecutingAssembly().GetName().Version.ToString());
                    // ProductInfoHeaderValue userAgent = new ProductInfoHeaderValue(header);
                    //  client.DefaultRequestHeaders.UserAgent.Add(userAgent);

                    string responseBody = "";
                    // Build the parameterized query then spawns a thread to return the responseBody as a string in an asyhonchronous operation. 
                    var builder   = new UriBuilder(_settings.BaseURL + "/search");
                    var query     = HttpUtility.ParseQueryString(builder.Query);
                    query.Add("term", _settings.SearchTerm);
                    query.Add("limit", _settings.JokesPerPage);
                    builder.Query = query.ToString();
                    string url    = builder.ToString();
                    try
                    {
                        responseBody =await client.GetStringAsync(url).ConfigureAwait(false);
                    }
                    catch(Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                   

                    // Bind the responseBody to our DadJokes object
                    DadJokes dadJokes = JsonConvert.DeserializeObject<DadJokes>(responseBody);
                   if (dadJokes.Status.Equals("200") &&  dadJokes.Results.Count != 0)
                    {
                        GroupDadJokesByLength(dadJokes);
                    }
                    else if (dadJokes.Results.Count != 0)
                    {
                        Console.WriteLine("Your search terms resulted in no jokes.");
                    }

                    Console.WriteLine("Press any key to exit.");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e);
                Console.WriteLine("Press any key to exit.");
            }

        }


        /*
         * GroupDadJokesByLength(DadJokes dadJokes) is called by SearchDadJokes to 
         * sort the resulting Dad Jokes by length and display them by grouped length beginning with short jokes first.
         * Note: during  my testing I was not able to find jokes with a length under 20 so they 
         * all came out under Long Jokes
         */
        private void GroupDadJokesByLength(DadJokes dadJokes)
        {
            IList<DadJoke> shortJokes = new List<DadJoke>();
            IList<DadJoke> mediumJokes = new List<DadJoke>();
            IList<DadJoke> longJokes = new List<DadJoke>();

            foreach (DadJoke dadJoke in dadJokes.Results)
            {
                int wordCount = CountWords(dadJoke.Joke);

                if (wordCount < _settings.ShortJokeLimit)
                {
                    shortJokes.Add(dadJoke);
                }
                else if (wordCount > _settings.ShortJokeLimit && wordCount < _settings.MediumJokeLimit)
                {
                    mediumJokes.Add(dadJoke);
                }
                else
                {
                    longJokes.Add(dadJoke);
                }
            }

            if (shortJokes.Count != 0)
            {
                Console.WriteLine("*******************************************************");
                Console.WriteLine("Short jokes:");
                FormatAndDisplayDadJokes(shortJokes);
            }
            if (mediumJokes.Count != 0)
            {
                Console.WriteLine("*******************************************************");
                Console.WriteLine("Medium jokes:");
                FormatAndDisplayDadJokes(mediumJokes);
            }
            if (longJokes.Count != 0)
            {
                Console.WriteLine("*******************************************************");
                Console.WriteLine("Long jokes:");
                FormatAndDisplayDadJokes(longJokes);
            }
        }

        /// <summary>
        /// Counts the number of words using regular expression
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public int CountWords(string s)
        {
            MatchCollection collection = Regex.Matches(s, @"[\S]+");
            return collection.Count;
        }
    }
}
